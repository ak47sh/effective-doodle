// models/Property.ts
import mongoose, { Schema, Document } from 'mongoose';

// Define the structure of a Property document
interface Property extends Document {
  address: string;
  purchasePrice: number;
  currentPrice: number;
  outstandingMortgage: number;
  interestRate: number;
}

// Create the Property schema
const propertySchema: Schema = new Schema(
  {
    address: {
      type: String,
      required: true,
    },
    purchasePrice: {
      type: Number,
      required: true,
    },
    currentPrice: {
      type: Number,
      required: true,
    },
    outstandingMortgage: {
      type: Number,
      required: true,
    },
    interestRate: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt timestamps
  }
);

// Create and export the Property model
const PropertyModel = mongoose.models.Property || mongoose.model<Property>('Property', propertySchema);
export default PropertyModel;
