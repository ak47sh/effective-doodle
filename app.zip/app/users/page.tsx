'use client';

import React, { useEffect, useState } from 'react';
import Modal from '@/components/Modal'; // Import the modal component

interface User {
  _id: string;
  name: string;
  email: string;
}

const UsersPage = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState<string>('');
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null); // State to manage selected email for modal
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false); // State to manage modal visibility

  // Fetch users on component mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('/api/users');
        const data = await response.json();

        if (response.ok) {
          setUsers(data.users); // Set the fetched users to state
        } else {
          setError(data.message || 'Failed to fetch users');
        }
      } catch (error) {
        setError('Error fetching users');
      }
    };

    fetchUsers();
  }, []);

  // Handle clicking on a user's name
  const handleShowEmail = (email: string) => {
    setSelectedEmail(email); // Set the email to display in the modal
    setIsModalOpen(true); // Open the modal
  };

  // Handle closing the modal
  const handleCloseModal = () => {
    setIsModalOpen(false); // Close the modal
    setSelectedEmail(null); // Reset selected email
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 p-5 bg-white shadow rounded-lg">
      <h1 className="text-2xl font-bold mb-4">Users</h1>
      {error && <p className="text-red-500">{error}</p>}
      <div>
        {users.length > 0 ? (
          <ul className="space-y-4">
            {users.map((user) => (
              <li key={user._id} className="p-4 border border-gray-200 rounded-md">
                <button
                  onClick={() => handleShowEmail(user.email)}
                  className="text-blue-500 hover:text-blue-700 font-semibold"
                >
                  {user.name}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No users found</p>
        )}
      </div>

      {/* Modal for displaying email */}
      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        email={selectedEmail || ''}
      />
    </div>
  );
};

export default UsersPage;
