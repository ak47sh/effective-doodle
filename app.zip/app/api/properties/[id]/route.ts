import { NextResponse } from 'next/server';
import Property from '@/models/Property';
import connectToDatabase from '@/lib/mongodb';

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  const { id } = params;
  try {
    const { address, purchasePrice, currentPrice, outstandingMortgage, interestRate } = await request.json();

    // Connect to the database
    await connectToDatabase();

    // Find the property by ID and update it
    const updatedProperty = await Property.findByIdAndUpdate(
      id,
      { address, purchasePrice, currentPrice, outstandingMortgage, interestRate },
      { new: true }
    );

    if (!updatedProperty) {
      return NextResponse.json({ message: 'Property not found' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Property updated successfully', property: updatedProperty });
  } catch (error) {
    return NextResponse.json({ message: 'Error updating property', error: error.message }, { status: 500 });
  }
}
