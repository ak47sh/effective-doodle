// app/api/properties/route.ts (or pages/api/properties.ts)
import { NextResponse } from 'next/server';
import Property from '@/models/Property';
import connectToDatabase from '@/lib/mongodb';

export async function POST(request: Request) {
  try {
    const { address, purchasePrice, currentPrice, outstandingMortgage, interestRate } = await request.json();

    // Connect to the database
    await connectToDatabase();

    // Create a new property
    const newProperty = new Property({
      address,
      purchasePrice,
      currentPrice,
      outstandingMortgage,
      interestRate,
    });

    // Save the property to the database
    await newProperty.save();

    return NextResponse.json({ message: 'Property created successfully', property: newProperty });
  } catch (error) {
    return NextResponse.json({ message: 'Error creating property', error: error.message }, { status: 500 });
  }
}

export async function GET() {
    try {
      // Connect to the database
      await connectToDatabase();
  
      // Fetch all properties from the database
      const properties = await Property.find();
  
      // If no properties are found, send an empty array
      return NextResponse.json({ properties });
    } catch (error) {
      console.error('Error fetching properties:', error);
      return NextResponse.json({ message: 'Failed to fetch properties' }, { status: 500 });
    }
  }
