'use client';

import React, { useEffect, useState } from 'react';
import Modal from '@/components/Modal';

interface Property {
  _id: string;
  address: string;
  purchasePrice: number;
  currentPrice: number;
  outstandingMortgage: number;
  interestRate: number;
}

const PropertiesPage = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  // Fetch properties from the backend API
  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const response = await fetch('/api/properties');
        
        // Check if the response is okay (status 200)
        if (!response.ok) {
          throw new Error(`Failed to fetch properties. Status: ${response.status}`);
        }

        const data = await response.json();

        // Make sure the response contains the properties field
        if (data && data.properties) {
          setProperties(data.properties);
        } else {
          throw new Error('No properties data found.');
        }
      } catch (error) {
        console.error('Error fetching properties:', error);
        alert('Error fetching properties. Please try again later.');
      }
    };

    fetchProperties();
  }, []);

  // Open the modal for editing the property
  const handleEditProperty = (property: Property) => {
    setSelectedProperty(property);
    setIsModalOpen(true);
  };

  // Close the modal
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedProperty(null);
  };

  // Handle form submission to update the property
  const handleSubmit = async (formData: any) => {
    if (!selectedProperty) return;

    try {
      const response = await fetch(`/api/properties/${selectedProperty._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (response.ok) {
        alert('Property updated successfully!');
        handleCloseModal(); // Close the modal after submission
        // Optionally, refetch properties to show updated data
        const updatedProperties = properties.map((property) =>
          property._id === selectedProperty._id ? { ...property, ...formData } : property
        );
        setProperties(updatedProperties);
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error updating property:', error);
      alert('Failed to update property.');
    }
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-semibold my-8">Properties</h1>
      
      <div className="space-y-4">
        {properties.map((property) => (
          <button
            key={property._id}
            className="block w-60 py-2 px-4 bg-blue-500 text-white rounded hover:bg-blue-600"
            onClick={() => handleEditProperty(property)}
          >
            {property.address}
          </button>
        ))}
      </div>

      {/* Modal for editing the property */}
      {selectedProperty && (
        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          onSubmit={handleSubmit}
          initialData={selectedProperty}
        />
      )}
    </div>
  );
};

export default PropertiesPage;
